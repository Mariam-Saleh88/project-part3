import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/assignment.dart';
import '../Back End/assignments_provider.dart';

class SubAssignmentsScreen extends StatefulWidget {
  const SubAssignmentsScreen({super.key});

  @override
  State<SubAssignmentsScreen> createState() => _SubAssignmentsScreenState();
}

class _SubAssignmentsScreenState extends State<SubAssignmentsScreen> {
  @override
  Widget build(BuildContext context) {
    final Assignment assignment =
        ModalRoute.of(context)!.settings.arguments as Assignment;
    double width = MediaQuery.of(context).size.width;
    return FutureBuilder(
        future:
            Provider.of<AssignmentProvider>(context, listen: false).loadData(),
        builder: (context, snapshot) {
          String? subTaskName = "";
          String? subAssignmentDate;
          return Consumer<AssignmentProvider>(
              builder: ((context, provider, child) {
            final TextEditingController controller = TextEditingController();

            List<SubAssignment> subAssignments = [];
            for (var i in provider.subAssignments) {
              if (i.assignmentId == assignment.id) {
                subAssignments.add(i);
              }
            }

            subAssignmentDate ??=
                DateFormat('yyyy-MM-dd').format(DateTime.now());

            return Scaffold(
              resizeToAvoidBottomInset: false,
              appBar: AppBar(
                title: Text("${assignment.assignmentName!} Details"),
              ),
              body: Container(
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30))),
                width: width - 20,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: SizedBox(
                          width: width,
                          child: TextFormField(
                            initialValue: assignment.assignmentDescreption,
                            onChanged: (value) { assignment.assignmentDescreption = value;
                            },
                            decoration: const InputDecoration(
                                hintText: "Assignment Descreption"),
                          )),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                              width: 150,
                              child: TextField(
                                controller: controller,
                                onChanged: (value) {
                                  subTaskName = value;
                                },
                                decoration: const InputDecoration(
                                    hintText: "Subtask Name"),
                              )),
                          Row(
                            children: [
                              Text(subAssignmentDate!),
                              IconButton(
                                onPressed: (() async {
                                  DateTime? pickedDate = await showDatePicker(
                                      context: context,
                                      initialDate: DateTime.now(),
                                      firstDate: DateTime(1950),
                                      lastDate: DateTime(2040));

                                  setState(() {
                                    subAssignmentDate = DateFormat('yyyy-MM-dd')
                                        .format(pickedDate!);
                                  });
                                }),
                                icon: const Icon(Icons.date_range),
                              ),
                            ],
                          ),
                          IconButton(
                              onPressed: (() {
                                controller.clear();
                                FocusScope.of(context).unfocus();
                                SubAssignment subAssignment = SubAssignment(
                                    subAssignmentName: subTaskName == ""
                                        ? "SubAssignment"
                                        : subTaskName,
                                    assignmentId: assignment.id,
                                    subAssignmentDate: subAssignmentDate,
                                    subAssignmentDone: false);
                                provider.addSubAssignment(subAssignment);
                                setState(() {});
                              }),
                              icon: const Icon(Icons.send_outlined))
                        ],
                      ),
                    ),

                  ],
                ),
              ),
            );
          }));
        });
  }


}
