import 'package:flutter/material.dart';
import 'package:project/screens/sub_assignments.dart';
import 'package:provider/provider.dart';

import 'Back End/assignments_provider.dart';
import 'screens/inbox_screen.dart';

void main() {
  runApp(ChangeNotifierProvider(
    create: ((context) => AssignmentProvider()),
    child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      routes: {
        'subTasks': (context) => SubAssignmentsScreen(),
      },
      home: HomePage(title: 'Task Manager Application'),
    );
  }
}
